#!/bin/bash
#
# CREDEBL Full W3C Credential Issuance Flow
# Complete end-to-end script for establishing connection and issuing credentials
#
# Usage: ./full-issuance-flow.sh [options]
#
# This script will:
# 1. Check agent health
# 2. Create an OOB invitation
# 3. Generate and display QR code
# 4. Wait for connection establishment
# 5. Issue a W3C credential
# 6. Monitor until completion
#

set -e

# Default configuration
BASE_URL="${CREDEBL_BASE_URL:-http://localhost:8004}"
API_KEY="${CREDEBL_API_KEY:-}"
ORG_NAME="CREDEBL Issuer"
CREDENTIAL_TYPE="EmploymentCredential"
POSITION="Software Engineer"
QR_OUTPUT="/tmp/credebl_invitation_qr.png"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

show_help() {
    cat << EOF
CREDEBL Full W3C Credential Issuance Flow

This script performs the complete credential issuance workflow:
  1. Verifies agent is healthy
  2. Creates an OOB invitation
  3. Generates a QR code
  4. Waits for connection establishment
  5. Issues a W3C credential
  6. Monitors until completion

Usage: $0 [options]

Options:
  -b, --base-url   Agent admin URL (default: http://localhost:8004)
  -k, --api-key    Agent API key (required, or set CREDEBL_API_KEY)
  -n, --name       Organization name (default: CREDEBL Issuer)
  -t, --type       Credential type (default: EmploymentCredential)
  -p, --position   Job position (default: Software Engineer)
  -q, --qr-output  QR code output file (default: /tmp/credebl_invitation_qr.png)
  -h, --help       Show this help

Environment Variables:
  CREDEBL_API_KEY    Agent API key
  CREDEBL_BASE_URL   Agent admin URL

Example:
  export CREDEBL_API_KEY="your-api-key"
  $0 -n "Acme Corporation" -p "Senior Engineer"

EOF
    exit 0
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -b|--base-url) BASE_URL="$2"; shift 2 ;;
        -k|--api-key) API_KEY="$2"; shift 2 ;;
        -n|--name) ORG_NAME="$2"; shift 2 ;;
        -t|--type) CREDENTIAL_TYPE="$2"; shift 2 ;;
        -p|--position) POSITION="$2"; shift 2 ;;
        -q|--qr-output) QR_OUTPUT="$2"; shift 2 ;;
        -h|--help) show_help ;;
        *) echo -e "${RED}Unknown option: $1${NC}"; show_help ;;
    esac
done

# Validate inputs
if [ -z "$API_KEY" ]; then
    echo -e "${RED}Error: API key is required${NC}"
    echo "Set CREDEBL_API_KEY environment variable or use -k option"
    exit 1
fi

# Check dependencies
check_dependency() {
    if ! command -v "$1" &> /dev/null; then
        echo -e "${RED}Error: $1 is required but not installed${NC}"
        exit 1
    fi
}

check_dependency curl
check_dependency jq

# Header
clear
echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║        CREDEBL W3C Credential Issuance - Full Flow             ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}Base URL:${NC}        $BASE_URL"
echo -e "  ${CYAN}Organization:${NC}    $ORG_NAME"
echo -e "  ${CYAN}Credential Type:${NC} $CREDENTIAL_TYPE"
echo ""

# Step 1: Health Check
echo -e "${YELLOW}━━━ Step 1: Checking Agent Health ━━━${NC}"
AGENT_INFO=$(curl -s -H "authorization: $API_KEY" "${BASE_URL}/agent" 2>/dev/null)

if echo "$AGENT_INFO" | jq -e '.isInitialized == true' > /dev/null 2>&1; then
    AGENT_LABEL=$(echo "$AGENT_INFO" | jq -r '.label')
    AGENT_ENDPOINT=$(echo "$AGENT_INFO" | jq -r '.endpoints[0]')
    echo -e "  ${GREEN}✓${NC} Agent is healthy"
    echo -e "    Label: $AGENT_LABEL"
    echo -e "    Endpoint: $AGENT_ENDPOINT"
else
    echo -e "  ${RED}✗${NC} Agent health check failed"
    echo "    Response: $AGENT_INFO"
    exit 1
fi
echo ""

# Step 2: Get Issuer DID
echo -e "${YELLOW}━━━ Step 2: Fetching Issuer DID ━━━${NC}"
DIDS=$(curl -s -H "authorization: $API_KEY" "${BASE_URL}/dids")
ISSUER_DID=$(echo "$DIDS" | jq -r '.[0].did // empty')

if [ -n "$ISSUER_DID" ]; then
    echo -e "  ${GREEN}✓${NC} Issuer DID: $ISSUER_DID"
else
    echo -e "  ${RED}✗${NC} No DID found"
    exit 1
fi
echo ""

# Step 3: Create OOB Invitation
echo -e "${YELLOW}━━━ Step 3: Creating OOB Invitation ━━━${NC}"
INVITATION_PAYLOAD=$(cat << EOF
{
  "label": "$ORG_NAME",
  "goalCode": "issue-vc",
  "goal": "Issue Verifiable Credential",
  "handshake": true,
  "handshakeProtocols": [
    "https://didcomm.org/didexchange/1.x",
    "https://didcomm.org/connections/1.x"
  ],
  "autoAcceptConnection": true
}
EOF
)

INVITATION_RESPONSE=$(curl -s -X POST \
    -H "authorization: $API_KEY" \
    -H "Content-Type: application/json" \
    -d "$INVITATION_PAYLOAD" \
    "${BASE_URL}/didcomm/oob/create-invitation")

INVITATION_URL=$(echo "$INVITATION_RESPONSE" | jq -r '.invitationUrl // empty')
OOB_ID=$(echo "$INVITATION_RESPONSE" | jq -r '.outOfBandRecord.id // empty')

if [ -n "$INVITATION_URL" ]; then
    echo -e "  ${GREEN}✓${NC} Invitation created"
    echo -e "    OOB Record ID: $OOB_ID"
else
    echo -e "  ${RED}✗${NC} Failed to create invitation"
    echo "    Response: $INVITATION_RESPONSE"
    exit 1
fi
echo ""

# Step 4: Generate QR Code
echo -e "${YELLOW}━━━ Step 4: Generating QR Code ━━━${NC}"

# Try Python QR generation first
if command -v python3 &> /dev/null; then
    python3 << PYEOF
try:
    import qrcode
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data("$INVITATION_URL")
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save("$QR_OUTPUT")
    print("  ✓ QR code saved to: $QR_OUTPUT")
except ImportError:
    print("  ⚠ qrcode package not installed, using online generator")
    print("    Install with: pip install qrcode pillow")
except Exception as e:
    print(f"  ⚠ Error generating QR: {e}")
PYEOF
fi

# Display online QR generator link
ENCODED_URL=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$INVITATION_URL'))" 2>/dev/null || echo "$INVITATION_URL")
echo -e "  ${CYAN}Online QR Generator:${NC}"
echo -e "  https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=$ENCODED_URL"
echo ""

# Print ASCII QR if possible
if command -v python3 &> /dev/null; then
    python3 << 'PYEOF'
try:
    import qrcode
    qr = qrcode.QRCode(version=1, box_size=1, border=1)
    qr.add_data("""$INVITATION_URL""")
    qr.make(fit=True)
    print("\n  ASCII QR Code (scan with mobile wallet):\n")
    qr.print_ascii(invert=True)
except:
    pass
PYEOF
fi

echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${YELLOW}  Please scan the QR code with your mobile wallet now${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Step 5: Wait for Connection
echo -e "${YELLOW}━━━ Step 5: Waiting for Connection ━━━${NC}"
echo "Polling for connection establishment..."

CONNECTION_ID=""
MAX_WAIT=120
WAIT_TIME=0

while [ $WAIT_TIME -lt $MAX_WAIT ]; do
    CONNECTIONS=$(curl -s -H "authorization: $API_KEY" "${BASE_URL}/didcomm/connections")

    # Find most recent completed connection
    CONNECTION_ID=$(echo "$CONNECTIONS" | jq -r '
        [.[] | select(.state == "completed")] |
        sort_by(.createdAt) |
        reverse |
        .[0].id // empty
    ')

    if [ -n "$CONNECTION_ID" ]; then
        HOLDER_DID=$(echo "$CONNECTIONS" | jq -r ".[] | select(.id == \"$CONNECTION_ID\") | .theirDid // empty")
        echo -e "  ${GREEN}✓${NC} Connection established!"
        echo -e "    Connection ID: $CONNECTION_ID"
        echo -e "    Holder DID: $HOLDER_DID"
        break
    fi

    printf "\r  Waiting... (%ds / %ds)" $WAIT_TIME $MAX_WAIT
    sleep 3
    WAIT_TIME=$((WAIT_TIME + 3))
done

if [ -z "$CONNECTION_ID" ]; then
    echo -e "\n  ${RED}✗${NC} Timeout waiting for connection"
    exit 1
fi
echo ""

# Step 6: Issue Credential
echo -e "${YELLOW}━━━ Step 6: Issuing W3C Credential ━━━${NC}"

ISSUANCE_DATE=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

CREDENTIAL_PAYLOAD=$(cat << EOF
{
  "connectionId": "$CONNECTION_ID",
  "protocolVersion": "v2",
  "credentialFormats": {
    "jsonld": {
      "credential": {
        "@context": [
          "https://www.w3.org/2018/credentials/v1",
          "https://www.w3.org/2018/credentials/examples/v1"
        ],
        "type": ["VerifiableCredential", "$CREDENTIAL_TYPE"],
        "issuer": "$ISSUER_DID",
        "issuanceDate": "$ISSUANCE_DATE",
        "credentialSubject": {
          "id": "$HOLDER_DID",
          "employeeOf": {
            "name": "$ORG_NAME",
            "position": "$POSITION",
            "startDate": "2024-01-01"
          }
        }
      },
      "options": {
        "proofType": "Ed25519Signature2018",
        "proofPurpose": "assertionMethod"
      }
    }
  },
  "autoAcceptCredential": "always"
}
EOF
)

CRED_RESPONSE=$(curl -s -X POST \
    -H "authorization: $API_KEY" \
    -H "Content-Type: application/json" \
    -d "$CREDENTIAL_PAYLOAD" \
    "${BASE_URL}/didcomm/credentials/create-offer")

CREDENTIAL_ID=$(echo "$CRED_RESPONSE" | jq -r '.id // empty')

if [ -n "$CREDENTIAL_ID" ]; then
    echo -e "  ${GREEN}✓${NC} Credential offer sent"
    echo -e "    Credential ID: $CREDENTIAL_ID"
    echo -e "    Type: $CREDENTIAL_TYPE"
else
    echo -e "  ${RED}✗${NC} Failed to create credential offer"
    echo "    Response: $CRED_RESPONSE"
    exit 1
fi
echo ""

# Step 7: Monitor Credential State
echo -e "${YELLOW}━━━ Step 7: Monitoring Credential Exchange ━━━${NC}"
echo -e "${CYAN}Please accept the credential offer in your mobile wallet${NC}"
echo ""

MAX_WAIT=180
WAIT_TIME=0

while [ $WAIT_TIME -lt $MAX_WAIT ]; do
    CRED_STATUS=$(curl -s -H "authorization: $API_KEY" "${BASE_URL}/didcomm/credentials/${CREDENTIAL_ID}")
    STATE=$(echo "$CRED_STATUS" | jq -r '.state // "unknown"')

    case "$STATE" in
        "done"|"credential-issued")
            echo ""
            echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
            echo -e "${GREEN}║         🎉 CREDENTIAL ISSUED SUCCESSFULLY! 🎉                 ║${NC}"
            echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
            echo ""
            echo "The credential is now in the holder's wallet."
            echo ""

            # Get final credential details
            FORM_DATA=$(curl -s -H "authorization: $API_KEY" "${BASE_URL}/didcomm/credentials/${CREDENTIAL_ID}/form-data")

            if echo "$FORM_DATA" | jq -e '.credential.jsonld.proof' > /dev/null 2>&1; then
                echo -e "${CYAN}Issued Credential:${NC}"
                echo "$FORM_DATA" | jq '.credential.jsonld'
            fi

            echo ""
            echo "━━━ Summary ━━━"
            echo "  Credential ID:   $CREDENTIAL_ID"
            echo "  Type:            $CREDENTIAL_TYPE"
            echo "  Issuer:          $ISSUER_DID"
            echo "  Holder:          $HOLDER_DID"
            echo "  Connection:      $CONNECTION_ID"
            echo ""
            exit 0
            ;;
        "offer-sent")
            printf "\r  ⏳ Waiting for holder to accept offer... (%ds)" $WAIT_TIME
            ;;
        "request-received")
            printf "\r  📨 Processing credential request... (%ds)      " $WAIT_TIME
            ;;
        *)
            printf "\r  State: %s (%ds)                    " "$STATE" $WAIT_TIME
            ;;
    esac

    sleep 3
    WAIT_TIME=$((WAIT_TIME + 3))
done

echo ""
echo -e "${RED}✗ Timeout waiting for credential exchange to complete${NC}"
echo "  Final state: $STATE"
echo ""
echo "Check agent logs for errors:"
echo "  docker logs YOUR_CONTAINER_NAME 2>&1 | tail -50"
exit 1
